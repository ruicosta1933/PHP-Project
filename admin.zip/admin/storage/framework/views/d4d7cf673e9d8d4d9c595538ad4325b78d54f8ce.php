<?php $__env->startSection('content'); ?>

    <div class="header bg-gradient-primary pb-8 pt-5 pt-md-8">
        <div class="container-fluid">
            <div class="header-body">
                <div class="row">
                    <div class="col">
                        <div class="card shadow">
                            <div class="card-header border-0">
                                <div class="row align-items-center">
                                    <div class="col-8">
                                        <h3 class="mb-0">About</h3>
                                    </div>
                                </div>
                            </div>

                            <div class="col-12">
                                <?php if(session('status')): ?>
                                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                                        <?php echo e(session('status')); ?>

                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                <?php endif; ?>
                            </div>
<?php if(isset($page)): ?>
                            <div class="table-responsive">
                                <table class="table align-items-center table-flush">
                                    <thead class="thead-light">
                                    <tr>
                                        <th scope="col"><?php echo e(__('Banner')); ?></th>
                                        <th scope="col"><?php echo e(__('Titulo')); ?></th>
                                        <th scope="col"><?php echo e(__('Texto')); ?></th>
                                        <th scope="col"></th>
                                    </tr>
                                    </thead>
                                    <tbody>

                                    <?php $__currentLoopData = $page; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pages): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <form method='POST' action='<?php echo e(route('about.update', $pages->id)); ?>' enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <tr>
                                                <td><input class='w3-input' type="file" name="banner" value="<?php echo e($pages->banner); ?>'"></td>
                                                <td>
                                                    <input class='w3-input'type='text' name='title' value='<?php echo e($pages->title); ?>'>



                                                </td>
                                                <td>
                                                    <textarea class='w3-input' name='text' type='text' value=' '><?php echo e($pages->text); ?></textarea>
                                                </td>

                                            </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php endif; ?>

                            <?php if(isset($page)): ?>
                                <div class="table-responsive">
                                    <table class="table align-items-center table-flush">
                                        <thead class="thead-light">
                                        <tr>
                                            <th scope="col"><?php echo e(__('Imagem 1')); ?></th>
                                            <th scope="col"><?php echo e(__('Imagem 2')); ?></th>
                                            <th scope="col"><?php echo e(__('Imagem 3')); ?></th>
                                            <th scope="col"></th>
                                        </tr>
                                        </thead>
                                        <tbody>

                                        <?php $__currentLoopData = $page; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pages): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>
                                                <tr>
                                                    <td><input class='w3-input' type="file" name="img1" value="<?php echo e($pages->img1); ?>'"></td>
                                                    <td><input class='w3-input' type="file" name="img2" value="<?php echo e($pages->img2); ?>'"></td>
                                                    <td><input class='w3-input' type="file" name="img3" value="<?php echo e($pages->img3); ?>'"></td>

                                                </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>

                            <?php if(isset($page)): ?>
                                <div class="table-responsive">
                                    <table class="table align-items-center table-flush">
                                        <thead class="thead-light">
                                        <tr>
                                            <th scope="col"><?php echo e(__('Legenda 1')); ?></th>
                                            <th scope="col"><?php echo e(__('Legenda 2')); ?></th>
                                            <th scope="col"><?php echo e(__('Legenda 3')); ?></th>
                                            <th scope="col"></th>
                                        </tr>
                                        </thead>
                                        <tbody>

                                        <?php $__currentLoopData = $page; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pages): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <tr>
                                                <td>
                                                    <input class='w3-input'type='text' name='desc1' value='<?php echo e($pages->descricao1); ?>'>
                                                </td>
                                                <td>
                                                    <input class='w3-input'type='text' name='desc2' value='<?php echo e($pages->descricao2); ?>'>
                                                </td>
                                                <td>
                                                    <input class='w3-input'type='text' name='desc3' value='<?php echo e($pages->descricao3); ?>'>
                                                </td>

                                                <td><button type='submit' class='btn btn-primary'>Editar</button></td>
                                            </tr>
                                            </form>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>

                            <div class="card-footer py-4">
                                <nav class="d-flex justify-content-end" aria-label="...">
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div><br>

        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => __('User Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\pap\admin\resources\views/page/about.blade.php ENDPATH**/ ?>